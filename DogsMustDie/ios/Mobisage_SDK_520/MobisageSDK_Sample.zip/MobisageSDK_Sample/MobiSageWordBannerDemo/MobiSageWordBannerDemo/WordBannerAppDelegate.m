//
//  WordBannerAppDelegate.m
//  MobiSageWordBannerDemo
//
//  Created by 左 顺兴 on 12-4-27.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "WordBannerAppDelegate.h"
#import "rootViewController.h"




@implementation WordBannerAppDelegate

@synthesize window = _window;

- (void)dealloc
{
    [_window release];
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    
    rootViewController * root = [[rootViewController alloc] init];
    self.window.rootViewController = root;
    
    
    [self.window makeKeyAndVisible];
    return YES;
}
@end
