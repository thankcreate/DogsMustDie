//
//  rootViewController.h
//  MobiSageWordBannerDemo
//
//  Created by stick on 13-1-21.
//  Copyright (c) 2013年 mobiSage. All rights reserved.
//

#import <UIKit/UIKit.h>


#import "MobiSageSDK.h"


@interface rootViewController : UIViewController <MobiSageAdViewDelegate>

@end
