//
//  WordBannerAppDelegate.h
//  MobiSageWordBannerDemo
//
//  Created by 左 顺兴 on 12-4-27.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WordBannerAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
