//
//  ViewController.m
//  MSTableRecommendDemo
//
//  Created by stick on 12-12-4.
//  Copyright (c) 2012年 stick. All rights reserved.
//

#import "ViewController.h"



#define MobiSage_Table_Recommend_Tag 1001  //表格式荐计划视图的tag值






@interface ViewController ()

@end

@implementation ViewController



@synthesize tableView=_tableView;
@synthesize recommendView;




- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    
    
    
    //表格式荐计划
    if (UIUserInterfaceIdiomPad == [UIDevice currentDevice].userInterfaceIdiom) {
        
        self.recommendView = [[[MSRecommendContentView alloc] initWithdelegate:self width:700.0f adCount:4] autorelease];
        
    }else {
        
        self.recommendView = [[[MSRecommendContentView alloc] initWithdelegate:self width:300.0f adCount:4] autorelease];
        
    }
    
    self.recommendView.tag = MobiSage_Table_Recommend_Tag;
    
    
    
    //表格控件
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];
    [self.tableView release];
    
}



- (void)viewDidUnload {
    
    
    self.tableView = nil;
    self.recommendView = nil;
    
    [super viewDidUnload];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark - UITableViewDataSource 委托函数
#pragma mark


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    
    // Return the number of sections.
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    
    // Return the number of rows in the section.
    if (0 == section) {
        
        return 2;
    }
    
    if (1 == section) {
        
        return 1;
        
    }
    
    if (2 == section) {
        
        return 2;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    //UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (![cell isKindOfClass:[UITableViewCell class]]) {
        
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    // Configure the cell...
    
    if (1 == indexPath.section) {
        
        cell.textLabel.text = nil;
        UIView *subView = [cell.contentView viewWithTag:MobiSage_Table_Recommend_Tag];
        if (subView != self.recommendView) {
            
            [cell.contentView addSubview:self.recommendView];
        }
        
    }else {
        
        UIView *subView = [cell.contentView viewWithTag:MobiSage_Table_Recommend_Tag];
        if (subView == self.recommendView) {
            
            [self.recommendView removeFromSuperview];
        }
        
        cell.textLabel.text = @"表格式荐计划";
    }
    
    return cell;
}





#pragma mark - UITableViewDelegate 委托函数
#pragma mark


- (float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    if (1 == indexPath.section) {
        
        if (UIUserInterfaceIdiomPad == [UIDevice currentDevice].userInterfaceIdiom) {
            
            return 157 * 4 *(700.0/640.0);
            
        }else {
            
            return 157 * 4 *(300.0/640.0);
        }
    }
    
    return 44;
}





- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    
}



#pragma mark - MobiSageRecommendDelegate 委托函数
#pragma mark

- (UIViewController *)viewControllerForPresentingModalView {
    
    return self;
}





@end
