//
//  AppDelegate.h
//  MSTableRecommendDemo
//
//  Created by stick on 12-12-4.
//  Copyright (c) 2012年 stick. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
