//
//  TencentLoginViewController.m
//  TencentApiDemo
//
//  Created by 左 顺兴 on 12-5-24.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "TencentLoginViewController.h"
#import "TencentMainViewController.h"
#import "MSTencentAccessToken.h"
#import "MobiSageSDK.h"
#import "JSONKit.h"
#import "Utility.h"

@implementation TencentLoginViewController

#pragma mark 请求腾讯服务器，获取授权的web代码
-(NSURLRequest*)getAuthorizeRequest
{
    NSMutableURLRequest* request = [[NSMutableURLRequest alloc] initWithURL:
                                    [NSURL URLWithString:[NSString stringWithFormat:Tencent_Weibo_Authorize,TencentApp_Key]]];
    [request setHTTPMethod:@"POST"];
    return [request autorelease];
}

- (id)init
{
    self = [super init];
    if (self) {
        
    }
    //创建UIWebView作为新浪微博的载体
    UIWebView *sinawebview= [UIWebView new];
    
    //设置webview的frame
    [sinawebview setFrame:self.view.frame];
    
    //给webview的委托赋值，将当前controller赋值给webview的委托
    //这一步很重要，否则无法接收webview的委托方法
    sinawebview.delegate = self;
    
    [self.view addSubview:sinawebview];
    //开始请求
    [[self.view.subviews objectAtIndex:0] loadRequest:[self getAuthorizeRequest]];
    return self;
}

-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    //获取服务器返回的字符串
    NSString* queryText = [[request URL] query];
    //若字符串为空则返回
    if(queryText == nil)
    {
        return YES;
    }
    //根据等号分割字符串
    NSArray* kvText = [queryText componentsSeparatedByString:@"="];
    NSLog(@"kvText:%@",kvText);
    if([[kvText objectAtIndex:0] isEqualToString:@"code"])
    {
        //setOpenID
        [[Utility getInstance] setTencent_OpenID:[[[kvText objectAtIndex:2] componentsSeparatedByString:@"&"] objectAtIndex:0]];
        //setOpenKey
        [[Utility getInstance] setTencent_OpenKey:[kvText objectAtIndex:3]];
        
        //根据在新浪注册的 Appkey 和 AppSecret 创建令牌对象
        MSTencentAccessToken *TokenPackage= [[MSTencentAccessToken alloc]initWithAppKey:TencentApp_Key Secret:TencentApp_Secret];
        //创建参数字典
        NSMutableDictionary* paramInfo = [NSMutableDictionary new];
        //此redirect_uri必须和请求code时的返回地址一致
        [paramInfo setObject:@"http://qq.com" forKey:@"redirect_uri"];
        [paramInfo setObject:[[[kvText objectAtIndex:1] componentsSeparatedByString:@"&"] objectAtIndex:0] forKey:@"code"];
        
        for(id key in [paramInfo allKeys])
        {
            [TokenPackage addParameter:key Value:[paramInfo objectForKey:key]];
        }
        //释放 paramInfo
        MSSafeRelease(paramInfo);
        //注册 MobiSagePackage_Finish 消息
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAccessTokenMobiSagePackageFinish:) name:MobiSagePackage_Finish object:TokenPackage];
        //将 TokenPackage Push进MabiSageManager
        [[MobiSageManager getInstance] pushMobiSagePackage:TokenPackage];
        return NO;
    }
    return YES;
}

#pragma mark MobiSagePackage_Finish消息的注册方法
-(void)onAccessTokenMobiSagePackageFinish:(NSNotification*)notify
{
    MSTencentAccessToken *package=(MSTencentAccessToken*)[notify object];
    NSLog(@"Status code %d",package->statusCode);
    NSString * resultStr = [[NSString alloc] initWithData:package->resultData encoding:NSUTF8StringEncoding];
    NSLog(@"%@",resultStr);
    NSArray * resultArray = [resultStr componentsSeparatedByString:@"="];
    MSSafeRelease(resultStr);
    NSLog(@"AccessToken %@",[[[resultArray objectAtIndex:1] componentsSeparatedByString:@"&"] objectAtIndex:0]);
    //setToken
    [[Utility getInstance] setTencent_AccessToken:[[[resultArray objectAtIndex:1] componentsSeparatedByString:@"&"] objectAtIndex:0]];
    TencentMainViewController *qqMainView=[[TencentMainViewController alloc]init];
    [[self navigationController]pushViewController:qqMainView animated:YES];
    [qqMainView release];
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

@end
