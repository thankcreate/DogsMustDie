//
//  Utility.h
//  TencentApiDemo
//
//  Created by 左 顺兴 on 12-5-24.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <Foundation/Foundation.h>

//腾讯的令牌和地址
//#define TencentApp_Key            @"801154525"
//#define TencentApp_Secret         @"33a1f4f858568e3d3f6661852056013d"

#define TencentApp_Key            @"801155236"
#define TencentApp_Secret         @"12af9c83bc192ae5f898bb226680fed5"

#define Tencent_Weibo_Authorize   @"https://open.t.qq.com/cgi-bin/oauth2/authorize?client_id=%@&response_type=code&redirect_uri=http://qq.com"
#define isPad (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)

//释放内存
#ifndef MSSafeRelease
#define MSSafeRelease(obj) if(obj!=nil){[obj release]; obj=nil;}
#endif
@interface Utility : NSObject
{
    //用来存储授权之后的Token，实际使用中建议本地存储
    NSString* Tencent_AccessToken;
    NSString* Tencent_OpenID;
    NSString* Tencent_OpenKey;
}
@property(nonatomic,copy)NSString* Tencent_AccessToken;
@property(nonatomic,copy)NSString* Tencent_OpenID;
@property(nonatomic,copy)NSString* Tencent_OpenKey;

//获取实例
+(Utility*)getInstance;
@end
