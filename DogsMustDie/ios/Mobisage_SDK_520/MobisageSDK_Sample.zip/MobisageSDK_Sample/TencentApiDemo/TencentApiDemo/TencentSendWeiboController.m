//
//  TencentSendWeiboController.m
//  TencentApiDemo
//
//  Created by 左 顺兴 on 12-5-24.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "TencentSendWeiboController.h"
#import "MobiSageSDK.h"
#import "MSTencentWeiboAdd.h"
#import "JSONKit.h"
#import "Utility.h"

@implementation TencentSendWeiboController

#pragma mark 创建UIButton
-(void) addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

#pragma mark Push消息
-(void)PushStatusAction:(id)sender
{
    if ([txtView text] !=nil &&[[txtView text] length]!=0)
    {
        //根据令牌创建消息包
        MSTencentWeiboAdd * recordsPackage = [[MSTencentWeiboAdd alloc] initWithAppKey:TencentApp_Key 
                                                                           AccessToken:[[Utility getInstance] Tencent_AccessToken]];
        //设置必要参数
        [recordsPackage addParameter:@"openid" Value:[[Utility getInstance] Tencent_OpenID]];
        //设置消息
        [recordsPackage addParameter:@"content" Value:[txtView text]];
        //完成后的消息
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onMobiSagePackageFinish:) name:MobiSagePackage_Finish object:recordsPackage];
        //发送
        [[MobiSageManager getInstance] pushMobiSagePackage:recordsPackage];
        MSSafeRelease(recordsPackage);
    }
    else
    {
        //没成功也得有点提示啊
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:@"消息不能为空！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        [alert release];
    }
}


#pragma mark 返回
-(void)CancelPushStatus:(id)sender
{
    [self dismissModalViewControllerAnimated:YES];
}

//完成后消息
-(void)onMobiSagePackageFinish:(NSNotification*) notify
{
    //线程安全调用方法
    [self performSelectorOnMainThread:@selector(PerformMobiSagePackageFinish:) withObject:notify waitUntilDone:NO];
}

//消息完成后的处理
-(void)PerformMobiSagePackageFinish:(NSNotification*) notify
{
    if ([[notify object] isKindOfClass:[MSTencentWeiboAdd class]]) {
        MSTencentWeiboAdd * package= (MSTencentWeiboAdd*)[notify object];
        NSDictionary* data=[[[JSONDecoder decoder]objectWithData:package->resultData] retain];
        
        NSLog(@"resultData is:%@",data);
        //判断消息类型并处理
        if ([[data objectForKey:@"ret"] intValue] == 0) {
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:@"成功" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
            [self dismissModalViewControllerAnimated:YES];
        }
        else
        {
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:[NSString stringWithFormat:@"失败，errorcode:%@,msg:%@,ret:%@",[data objectForKey:@"errorcode"],[data objectForKey:@"msg"],[data objectForKey:@"ret"]] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
            [self dismissModalViewControllerAnimated:YES];
        }
        [data release];
    }
}

#pragma mark 自定义初始化
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        [self navigationItem].title = @"发布记录";
        txtView=[[UITextView alloc] initWithFrame:CGRectMake(30, 30, self.view.bounds.size.width-60, (self.view.bounds.size.height-200)/2)];
        txtView.backgroundColor = [UIColor grayColor];
        [self.view addSubview:txtView];
        [txtView release];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width-80, self.view.bounds.size.height/2-50, 60, 40) withTitle:@"发送" andTag:1 andAction:@selector(PushStatusAction:)];
        [self addButtonInFrame:CGRectMake(30, self.view.bounds.size.height/2-50, 60, 40) withTitle:@"取消" andTag:2 andAction:@selector(CancelPushStatus:)];
        
    }
    return self;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

@end
