//
//  TencentMainViewController.m
//  TencentApiDemo
//
//  Created by 左 顺兴 on 12-5-24.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "TencentMainViewController.h"
#import "MobiSageSDK.h"
#import "MSTencentFriends.h"
#import "JSONKit.h"
#import "Utility.h"
#import "TencentSendWeiboController.h"
#import "TencentSendPicWeiboController.h"

@implementation TencentMainViewController

#pragma mark 创建UIButton
-(void) addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

#pragma mark 添加关注
-(void)MakeFriends:(id)sender
{
    //相应对象，同样根据令牌创建
    MSTencentFriends * pagebecomefanPackage = [[MSTencentFriends alloc] initWithAppKey:TencentApp_Key AccessToken:[[Utility getInstance] Tencent_AccessToken]];
    //关注参数
    [pagebecomefanPackage addParameter:@"name" Value:[pageidtxt text]];
    [pagebecomefanPackage addParameter:@"openid" Value:[[Utility getInstance] Tencent_OpenID]];
    //完成后消息
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onMobiSagePackageFinish:) name:MobiSagePackage_Finish object:pagebecomefanPackage];
    //发送
    [[MobiSageManager getInstance] pushMobiSagePackage:pagebecomefanPackage];
    MSSafeRelease(pagebecomefanPackage);
}

#pragma mark 完成后消息
-(void)onMobiSagePackageFinish:(NSNotification*) notify
{
    //线程安全的调用
    [self performSelectorOnMainThread:@selector(PerformMobiSagePackageFinish:) withObject:notify waitUntilDone:NO];
}

#pragma mark 完成后方法
-(void)PerformMobiSagePackageFinish:(NSNotification*) notify
{
    //判断消息类型
    if ([[notify object] isKindOfClass:[MSTencentFriends class]]) {
        //获取参数
        MSTencentFriends * package= (MSTencentFriends *)[notify object];
        //解析
        NSDictionary * Data = [[[JSONDecoder decoder] objectWithData:package->resultData] retain]; 
        NSLog(@"resultData is:%@",Data);
        //判断消息类型并出示相应提示
        if ([[Data objectForKey:@"ret"] intValue] == 0) {
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:@"加关注成功" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
            [alertView release];
        }
        else
        {
            NSLog(@"%@",[[Data objectForKey:@"errorcode"] class]);
            UIAlertView * alertView =[[UIAlertView alloc]initWithTitle:nil message:[NSString stringWithFormat:@"加关注失败，%@",[Data objectForKey:@"msg"]] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
        }
    }
    
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isKindOfClass: [UIButton class]] )
    {    
        return NO;
    }
    return YES;
}

-(void)done:(id)sender
{  
    for (UIView *view in self.view.subviews)
    {  
        if ([view isKindOfClass:[UITextField class]]) 
        {  
            [view resignFirstResponder];
            
        }
    }
}

#pragma mark 发微博
-(void)SendRecord:(id)sender
{
    TencentSendWeiboController * send = [TencentSendWeiboController new];
    [[self navigationController] pushViewController:send animated:YES];
    [send release];
}

#pragma mark 相册
-(void)Album:(id)sender
{
    TencentSendPicWeiboController * pic = [[TencentSendPicWeiboController alloc] init];
    [[self navigationController] pushViewController:pic animated:YES];
    [pic release];
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.navigationItem.title = @"功能界面";
        [[self view] setBackgroundColor:[UIColor whiteColor]];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2-65, 90, 50) withTitle:@"关注" andTag:1 andAction:@selector(MakeFriends:)];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2+15, 90, 50) withTitle:@"发微博" andTag:1 andAction:@selector(SendRecord:)];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2+95, 90, 50) withTitle:@"图片微博" andTag:1 andAction:@selector(Album:)];
        UILabel* pageid=[[[UILabel alloc]initWithFrame:CGRectMake(30, 30, 90, 40)]autorelease];
        pageidtxt=[[[UITextField alloc]initWithFrame:CGRectMake(150, 30, 150, 40)]autorelease];
        [pageid setText:@"PageID:"];
        [pageidtxt setBorderStyle:UITextBorderStyleLine];
        [pageidtxt setText:@"1799200648"];
        [self.view addSubview:pageidtxt];
        [self.view addSubview:pageid];

    }
    return self;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

@end
