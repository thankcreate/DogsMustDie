//
//  Utility.m
//  TencentApiDemo
//
//  Created by 左 顺兴 on 12-5-24.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "Utility.h"

@implementation Utility
@synthesize Tencent_AccessToken,Tencent_OpenID,Tencent_OpenKey;

static Utility* utility_Instance = nil;

+(Utility*)getInstance
{
    @synchronized(self)
    {
        if(utility_Instance == nil)
        {
            utility_Instance = [Utility new];
        }
    }
    return utility_Instance;
}

@end
