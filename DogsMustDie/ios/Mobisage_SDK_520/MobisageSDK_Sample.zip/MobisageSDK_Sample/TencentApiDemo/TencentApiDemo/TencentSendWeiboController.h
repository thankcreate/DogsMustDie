//
//  TencentSendWeiboController.h
//  TencentApiDemo
//
//  Created by 左 顺兴 on 12-5-24.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TencentSendWeiboController : UIViewController
{
    UITextView* txtView;
}
@end
