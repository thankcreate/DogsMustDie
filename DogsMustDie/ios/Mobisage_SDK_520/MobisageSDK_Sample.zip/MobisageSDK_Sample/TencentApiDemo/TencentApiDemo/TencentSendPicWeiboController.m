//
//  TencentSendPicWeiboController.m
//  TencentApiDemo
//
//  Created by 左 顺兴 on 12-5-25.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "TencentSendPicWeiboController.h"
#import "MobiSageSDK.h"
#import "MSTencentPicWeibo.h"
#import "JSONKit.h"
#import "Utility.h"

@implementation TencentSendPicWeiboController

#pragma mark 创建UIButton
-(void) addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

#pragma mark Push消息
-(void)PushStatusAction:(id)sender
{
    if (imageFilePath == nil || [imageFilePath isEqualToString:@""]) {
        UIAlertView *alertView =[[UIAlertView alloc] initWithTitle:nil message:@"请先选择照片" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alertView show];
        [alertView release];
        return;
    }
    //点击按钮开始上传
    MSTencentPicWeibo * picWeibo = [[MSTencentPicWeibo alloc] initWithAppKey:TencentApp_Key AccessToken:[[Utility getInstance] Tencent_AccessToken]];
    
    //设置必要参数
    [picWeibo addParameter:@"openid" Value:[[Utility getInstance] Tencent_OpenID]];
    //设置消息
    [picWeibo addParameter:@"content" Value:[txtView text]];
    [picWeibo addParameter:@"pic" Value:imageFilePath];
    //完成后的消息
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onMobiSagePackageFinish:) name:MobiSagePackage_Finish object:picWeibo];
    //发送
    [[MobiSageManager getInstance] pushMobiSagePackage:picWeibo];
    MSSafeRelease(picWeibo);
}


//完成后消息
-(void)onMobiSagePackageFinish:(NSNotification*) notify
{
    //线程安全调用方法
    [self performSelectorOnMainThread:@selector(PerformMobiSagePackageFinish:) withObject:notify waitUntilDone:NO];
}

//消息完成后的处理
-(void)PerformMobiSagePackageFinish:(NSNotification*) notify
{
    if ([[notify object] isKindOfClass:[MSTencentPicWeibo class]]) {
        MSTencentPicWeibo * package= (MSTencentPicWeibo*)[notify object];
        NSDictionary* data=[[[JSONDecoder decoder]objectWithData:package->resultData] retain];
        
        NSLog(@"resultData is:%@",data);
        //判断消息类型并处理
        if ([[data objectForKey:@"ret"] intValue] == 0) {
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:@"成功" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
            [self dismissModalViewControllerAnimated:YES];
        }
        else
        {
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:[NSString stringWithFormat:@"失败，errorcode:%@,msg:%@,ret:%@",[data objectForKey:@"errorcode"],[data objectForKey:@"msg"],[data objectForKey:@"ret"]] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
            [self dismissModalViewControllerAnimated:YES];
        }
        [data release];
    }
}

-(void)selectImg:(id)sender
{
    //点击按钮选择照片
    NSLog(@"%@",NSStringFromSelector(_cmd));
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        UIImagePickerController * picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        
        if (isPad) {
            popoverController = [[UIPopoverController alloc] initWithContentViewController:picker];;
            [popoverController presentPopoverFromRect:CGRectMake(0, 0, 300, 300) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            [picker release];
        }else {
            [self presentModalViewController:picker animated:YES];
            [picker release];
        }
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"连接到图片库错误"
                              message:@""
                              delegate:nil
                              cancelButtonTitle:@"确定"
                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
    
}
- (NSString *)getImageFilePath
{
    NSArray * paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString * documentsDirectory = [paths objectAtIndex:0];
    return [documentsDirectory stringByAppendingPathComponent:@"image.png"];
}

#pragma mark 自定义初始化
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        [self navigationItem].title = @"发布带图片的微博";
        txtView=[[UITextView alloc] initWithFrame:CGRectMake(30, 20, 70, 70)];
        txtView.backgroundColor = [UIColor grayColor];
        [self.view addSubview:txtView];
        [txtView release];
        
        
        imgView = [[UIImageView alloc] initWithFrame:CGRectMake(130, 20, 70, 70)];
        imgView.backgroundColor = [UIColor grayColor];
        [self.view addSubview:imgView];
        
        [self addButtonInFrame:CGRectMake(20, 120, 60, 40) withTitle:@"发送" andTag:1 andAction:@selector(PushStatusAction:)];
                
        [self addButtonInFrame:CGRectMake(180, 120, 60, 40) withTitle:@"选择" andTag:3 andAction:@selector(selectImg:)];
        
        imageFilePath = [[self getImageFilePath] retain];
        
    }
    return self;
}

- (BOOL)writeImage:(UIImage*)image
{
    if ((image == nil) || (imageFilePath == nil) || ([imageFilePath isEqualToString:@""]))
        return NO;
    @try
    {
        NSData *imageData = nil;
        NSString *ext = [imageFilePath pathExtension];
        if ([ext isEqualToString:@"png"])
        {
            imageData = UIImagePNGRepresentation(image);
        }
        else
        {
            // the rest, we write to jpeg
            // 0. best, 1. lost. about compress.
            imageData = UIImageJPEGRepresentation(image, 0);
        }
        
        if ((imageData == nil) || ([imageData length] <= 0))
            return NO;
        
        [imageData writeToFile:imageFilePath atomically:YES];
        return YES;
    }
    @catch (NSException *e)
    {
        NSLog(@"create thumbnail exception.");
    }
    return NO;
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
    [imgView setImage:image];
    if (isPad) {
        [popoverController dismissPopoverAnimated:YES];
    } else {
        [picker dismissModalViewControllerAnimated:YES];
    }
    //苹果不提供路径，所以只能自己先存起来，从而拿到路径
    if ([self writeImage:image]) {
//        NSLog(@"Save Image Success!!!");
    }
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

@end
