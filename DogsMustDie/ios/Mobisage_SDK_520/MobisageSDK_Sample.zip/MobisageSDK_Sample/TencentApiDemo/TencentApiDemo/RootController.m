//
//  RootController.m
//  TencentApiDemo
//
//  Created by 左 顺兴 on 12-5-24.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "RootController.h"
#import "Utility.h"
#import "TencentMainViewController.h"
#import "TencentLoginViewController.h"

@implementation RootController

#pragma mark 创建UILabel
-(void) addLabelInFrame:(CGRect)frame withTitle:(NSString*)title andTag:(NSInteger)tag
{
    UILabel* label = [UILabel new];
    [label setFrame:frame];
    [label setText:title];
    [label setTextAlignment:UITextAlignmentCenter];
    [label setTag:tag];
    [label setTextAlignment:UITextAlignmentLeft];
    [self.view addSubview:label];
    MSSafeRelease(label);
}
#pragma mark 创建UIButton
-(void) addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

- (id)init
{
    self = [super init];
    if (self) {
        // 因为是测试程序，并未通过认证，所以可以授权的账号有限，本程序使用固定测试账号登陆
        [self addLabelInFrame:CGRectMake(30, 30, 260, 30) withTitle:@"请用以下或你自己的账号登陆" andTag:1];
        [self addLabelInFrame:CGRectMake(30, 70, 260, 30) withTitle:@"用户名:1799200648" andTag:2];
        [self addLabelInFrame:CGRectMake(30, 110, 260, 30) withTitle:@"密码:appsage" andTag:3];
        
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2-65, 90, 45) withTitle:@"登陆" andTag:4 andAction:@selector(TencentToAccessTokenView:)];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2+15, 90, 45) withTitle:@"退出" andTag:5 andAction:@selector(TencentLogOut:)];
    }
    return self;
}

#pragma mark 执行登陆判断操作
-(void)TencentToAccessTokenView:(id)sender
{
    //判断令牌是否为空，作为是否登陆的凭证，此凭证在实际应用中建议本地存储，防止每次启动重复登录
    if ([[Utility getInstance] Tencent_AccessToken]==nil || [[[Utility getInstance] Tencent_AccessToken] isEqualToString:@""]) 
    {
        TencentLoginViewController* qqLogincController=[[TencentLoginViewController alloc]init];
        [[self navigationController] pushViewController:qqLogincController animated:YES];
        [qqLogincController release];
    }
    else
    {
        TencentMainViewController* qqMainView=[[TencentMainViewController alloc]init];
        [[self navigationController]pushViewController:qqMainView animated:YES];
        [qqMainView release];
    }
}

#pragma mark 退出登录，即清空令牌
- (void)TencentLogOut:(id)sender
{
    if ([[Utility getInstance] Tencent_AccessToken]!=nil) 
    {
        [[Utility getInstance] setTencent_AccessToken:@""];
    }
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

@end
