//
//  main.m
//  MobiSageBaiduBarTrackingDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SampleAppDelegate.h"
#import "MobiSageSDK.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        //此处设置PublishID
        [[MobiSageManager getInstance] setPublisherID:MobiSage_PublisherId_Test];
        //发送程序启动Track
        [[MobiSageManager getInstance] trackSystemEvent:AppLaunchingEvent WithObject:@"MobiSageBaiduBarTrackingDemo LaunchingEvent"];
        //也可以这样
        [[MobiSageManager getInstance] trackSystemEvent:AppLaunchingEvent];
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SampleAppDelegate class]));
    }
}
