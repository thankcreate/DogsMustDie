//
//  SampleAppDelegate.h
//  MobiSageBaiduBarTrackingDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SampleAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
