//
//  SampleAppDelegate.m
//  MobiSageBaiduBarTrackingDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "SampleAppDelegate.h"
#import "MobiSageSDK.h"
@implementation SampleAppDelegate

@synthesize window = _window;

- (void)dealloc
{
    [_window release];
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    
    //添加时尽量靠上，否则弹出键盘可能会遮盖百度工具条
    MobiSageBaiduBar * baiduBar = [[MobiSageBaiduBar alloc] initWithFrame:CGRectMake(0, 50, 320, 40)];
    [self.window addSubview:baiduBar];
    [baiduBar release];

    //track
    UIButton * btnTrack = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btnTrack.frame = CGRectMake(250, 400, 60, 30);
    [btnTrack setTitle:@"Track" forState:UIControlStateNormal];
    [btnTrack addTarget:self action:@selector(onTrack:) forControlEvents:UIControlEventTouchUpInside];
    [self.window addSubview:btnTrack];
    
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)onTrack:(id)sender
{
    //这里是各种track的示例
    [[MobiSageManager getInstance] trackSystemEvent:AppLaunchingEvent];
    [[MobiSageManager getInstance] trackSystemEvent:CustomerEvent WithObject:@"This is customerEvent"];
    [[MobiSageManager getInstance] trackCustomerEvent:@"CustomerEventName" WithObject:@"CustomerTrack"];
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
    
    //可以在这里发送Track
    [[MobiSageManager getInstance] trackSystemEvent:AppTerminatingEvent];
    //或者
    [[MobiSageManager getInstance] trackSystemEvent:AppTerminatingEvent WithObject:@"applicationDidEnterBackground"];
    //或者
    [[MobiSageManager getInstance] trackCustomerEvent:@"applicationDidEnterBackground" WithObject:@"applicationDidEnterBackground"];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
    //可以在这里发送Track
    [[MobiSageManager getInstance] trackSystemEvent:AppLaunchingEvent];
    //或者
    [[MobiSageManager getInstance] trackSystemEvent:AppLaunchingEvent WithObject:@"applicationWillEnterForeground"];
    //或者
    [[MobiSageManager getInstance] trackCustomerEvent:@"applicationWillEnterForeground" WithObject:@"applicationWillEnterForeground"];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
    
    //也可以是这里
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    /*
     Called when the application is about to terminate.
     Save data if appropriate.
     See also applicationDidEnterBackground:.
     */
}

@end
