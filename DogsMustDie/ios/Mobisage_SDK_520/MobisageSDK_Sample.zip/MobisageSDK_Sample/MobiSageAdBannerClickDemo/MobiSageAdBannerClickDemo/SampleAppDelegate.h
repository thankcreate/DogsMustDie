//
//  SampleAppDelegate.h
//  MobiSageAdBannerClickDemo
//
//  Created by 左 顺兴 on 12-8-8.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "rootController.h"

@interface SampleAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) rootController *root;
@end
