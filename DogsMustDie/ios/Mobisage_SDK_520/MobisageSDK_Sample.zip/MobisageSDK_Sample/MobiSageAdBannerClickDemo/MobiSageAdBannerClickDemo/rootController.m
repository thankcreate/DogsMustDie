//
//  rootController.m
//  MobiSageAdBannerClickDemo
//
//  Created by 左 顺兴 on 12-8-8.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "rootController.h"


@implementation rootController


#pragma mark - MobiSageAdViewDelegate 委托
#pragma mark

- (UIViewController *)viewControllerToPresent {
    
    
    return self;
}







- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        //创建广告
        MobiSageAdBanner * adBanner = [[MobiSageAdBanner alloc] initWithAdSize:Ad_320X50 withDelegate:self];

        //设置广告轮显方式
        [adBanner setSwitchAnimeType:Random];
        adBanner.frame = CGRectMake(0, 20, 320, 50);
        [self.view addSubview:adBanner];
        [adBanner release];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(adViewClick:) name:MobiSageAdView_Click_AD object:nil];
    }
    return self;
}

-(void)adViewClick:(NSNotification *)notify
{
    NSLog(@"adViewClick 点击了Banner！");
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}






@end
