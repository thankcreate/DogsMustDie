//
//  ViewController.h
//  AdsageRecommendDemo
//
//  Created by stick on 12-9-14.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MobiSageSDK.h"




@interface ViewController : UIViewController<MobiSageRecommendDelegate>


@property(nonatomic, retain) MobiSageRecommendView *recomendView1;
@property(nonatomic, retain) MobiSageRecommendView *recomendView2;
@property(nonatomic, retain) MobiSageRecommendView *recomendView3;








@end
