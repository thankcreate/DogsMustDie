//
//  main.m
//  AdsageRecommendDemo
//
//  Created by stick on 12-9-14.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"
#import "MobiSageSDK.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        
        [[MobiSageManager getInstance] setPublisherID:MobiSage_PublisherId_Test];
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
