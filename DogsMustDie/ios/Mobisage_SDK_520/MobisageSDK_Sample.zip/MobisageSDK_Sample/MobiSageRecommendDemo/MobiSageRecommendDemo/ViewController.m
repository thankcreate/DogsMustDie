//
//  ViewController.m
//  AdsageRecommendDemo
//
//  Created by stick on 12-9-14.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController


@synthesize recomendView1;
@synthesize recomendView2;
@synthesize recomendView3;




#pragma mark - MobiSageRecommendDelegate 委托函数
#pragma mark

- (UIViewController *)viewControllerForPresentingModalView {
    
    return self;
}

//弹出荐计划广告的按钮触摸事件响应函数
- (void)openRecommendView {
    
    [self.recomendView3 OpenAdSageRecmdModalView];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    
    
    //1.构造方式一，由开发传入一张图片资源，然后用户点击图片后，弹出荐计划广告
    
    //1.1 使用 AdSageRecommendBundle.bundle 提供的图片资源 
    NSString *strResourceBundlePath = [[NSBundle mainBundle] pathForResource:@"MobiSageRecommendBundle" ofType:@"bundle"];
    NSString *strBgImagePath = nil;
    if (UIUserInterfaceIdiomPad == [[UIDevice currentDevice] userInterfaceIdiom]) {
        
        strBgImagePath = [strResourceBundlePath stringByAppendingPathComponent:@"/recommend/AdSageRecmd_0_iPad.png"];
        
    }else{
        
        strBgImagePath = [strResourceBundlePath stringByAppendingPathComponent:@"/recommend/AdSageRecmd_0_iPhone.png"];
    }
    
    UIImage *image = [UIImage imageWithContentsOfFile:strBgImagePath];
    self.recomendView1 = [[MobiSageRecommendView alloc] initWithDelegate:self andImg:image];
    self.recomendView1.frame = CGRectMake(50, 50, image.size.width, image.size.height);
    [self.view addSubview:self.recomendView1];
    [self.recomendView1 release];
    
    
    //2.构造方式二，开发者不需传入图片，使用默认的图片代替，用户点击默认图片弹出荐计划广告
    self.recomendView2 = [[MobiSageRecommendView alloc] initWithDelegate:self andImg:nil];
    //调整荐计划按钮位置
    CGRect rect2 = self.recomendView2.frame;
    rect2.origin.x = 50;
    rect2.origin.y = 150;
    self.recomendView2.frame = rect2;
    [self.view addSubview:self.recomendView2];
    [self.recomendView2 release];
    
    
    //3.构造方式三，开发者不需传入图片，也不使用默认图片，当开发者想弹出荐计划广告时，调用【[self.recomendView3 OpenAdSageRecmdModalView];】弹出荐计划广告,本例使用一个button重发
    self.recomendView3 = [[MobiSageRecommendView alloc] initWithDelegate:self];
    //调整荐计划按钮位置
    CGRect rect3 = self.recomendView3.frame;
    rect3.origin.x = 50;
    rect3.origin.y = 250;
    self.recomendView3.frame = rect3;
    [self.view addSubview:self.recomendView3];
    [self.recomendView3 release];
    
    
    //触发弹出荐计划广告的按钮
    UIButton *btnUser = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btnUser.frame = CGRectMake(60, 400, 200, 40);
    [btnUser addTarget:self action:@selector(openRecommendView)forControlEvents:UIControlEventTouchUpInside];
    [btnUser setTitle:@"弹出荐计划广告" forState:UIControlStateNormal];
    [self.view addSubview:btnUser];
    
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    
    self.recomendView1 = nil;
    self.recomendView2 = nil;
    self.recomendView3 = nil;
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

@end
