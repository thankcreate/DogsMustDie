//
//  RootController.m
//  MobiSageAdPosterDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "RootController.h"
#import "PostAdView.h"

@implementation RootController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        btn.frame = CGRectMake(10, 30, 100, 40);
        [btn setTitle:@"弹出PosAd" forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(onBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
        
    }
    return self;
}

- (void)onBtnClick:(id)sender
{
    //弹出该页
    PostAdView * posView = [[PostAdView alloc] init];
    [self.navigationController pushViewController:posView animated:YES];
    [posView release];
}
@end
