//
//  PostAdView.h
//  MobiSageAdPosterDemo
//
//  Created by zuo shunxing on 12-2-29.
//  Copyright (c) 2012年 APP. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MobiSageSDK.h"

@interface PostAdView : UIViewController <MobiSageAdViewDelegate>
{
    MobiSageAdPoster * adPoster;
    UIButton * btn;
    UIButton * btnRemove;
}
@end
