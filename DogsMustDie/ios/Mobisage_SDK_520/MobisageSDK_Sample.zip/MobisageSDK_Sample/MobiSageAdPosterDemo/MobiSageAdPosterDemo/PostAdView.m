//
//  PostAdView.m
//  MobiSageAdPosterDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "PostAdView.h"


@implementation PostAdView


#pragma mark - MobiSageAdViewDelegate 委托
#pragma mark

- (UIViewController *)viewControllerToPresent {
    
    
    return self;
}


- (id)init
{
    self = [super init];
    if (self) {
        self.view.backgroundColor = [UIColor greenColor];
        adPoster = [[MobiSageAdPoster alloc] initWithAdSize:Poster_320X460 withDelegate:self];//Size用Poster枚举
        //请求广告
        [adPoster startRequestAD];
        
        [self.view addSubview:adPoster];
        [adPoster release];
        
        btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        btn.frame = CGRectMake(10, 10, 100, 30);
        [btn.titleLabel setTextAlignment:UITextAlignmentCenter];
        [btn setTitle:@"RequestAD" forState:UIControlStateNormal];
        [btn.titleLabel setTextColor:[UIColor redColor]];
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
        
        btnRemove = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        btnRemove.frame = CGRectMake(130, 10, 100, 30);
        [btnRemove setTitle:@"removeAd" forState:UIControlStateNormal];
        [btnRemove addTarget:self action:@selector(onRemoveClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btnRemove];        
    }
    return self;
}

- (void)onRemoveClick:(id)sender
{
    [adPoster removeFromSuperview];
    adPoster = nil;
    btn.enabled = false;
    btnRemove.enabled = false;
}

- (void)btnClick:(id)sender
{
    if (adPoster != nil) {
        //请求新广告
        [adPoster startRequestAD];
    }
    
}
@end
