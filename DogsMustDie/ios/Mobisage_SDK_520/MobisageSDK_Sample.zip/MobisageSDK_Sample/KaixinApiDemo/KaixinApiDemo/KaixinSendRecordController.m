//
//  KaixinSendRecordController.m
//  KaixinApiDemo
//
//  Created by 左 顺兴 on 12-4-25.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "KaixinSendRecordController.h"
#import "MobiSageSDK.h"
#import "MSKaixinRecordsUpload.h"
#import "JSONKit.h"
#import "Utility.h"

@implementation KaixinSendRecordController


#pragma mark 创建UIButton
-(void) addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

#pragma mark Push消息
-(void)PushStatusAction:(id)sender
{
    if ([txtView text] !=nil &&[[txtView text] length]!=0)
    {
        //根据令牌创建消息包
        MSKaixinRecordsUpload * recordsPackage = [[MSKaixinRecordsUpload alloc] initWithAppKey:KaixinApp_Key AccessToken:[[Utility getInstance] kaixin_AccessToken]];
        //设置消息
        [recordsPackage addParameter:@"content" Value:[txtView text]];
        //完成后的消息
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onMobiSagePackageFinish:) name:MobiSagePackage_Finish object:recordsPackage];
        //发送
        [[MobiSageManager getInstance] pushMobiSagePackage:recordsPackage];
        MSSafeRelease(recordsPackage);
    }
    else
    {
        //没成功也得有点提示啊
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:@"消息不能为空！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        [alert release];
    }
}


#pragma mark 返回
-(void)CancelPushStatus:(id)sender
{
    [self dismissModalViewControllerAnimated:YES];
}

//完成后消息
-(void)onMobiSagePackageFinish:(NSNotification*) notify
{
    //线程安全调用方法
    [self performSelectorOnMainThread:@selector(PerformMobiSagePackageFinish:) withObject:notify waitUntilDone:NO];
}

//消息完成后的处理
-(void)PerformMobiSagePackageFinish:(NSNotification*) notify
{
    if ([[notify object] isKindOfClass:[MSKaixinRecordsUpload class]]) {
        MSKaixinRecordsUpload * package= (MSKaixinRecordsUpload*)[notify object];
        NSDictionary* data=[[[JSONDecoder decoder]objectWithData:package->resultData] retain];
        
        NSLog(@"resultData is:%@",data);
        NSLog(@"error_code is:%@",[data objectForKey:@"error_code"]);
        NSLog(@"error is:%@",[data objectForKey:@"error"]);
        //判断消息类型并处理
        if ([[data objectForKey:@"rid"] intValue] > 0) {
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:@"成功" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
            [self dismissModalViewControllerAnimated:YES];
        }
        else
        {
            
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:[NSString stringWithFormat:@"失败，%@",[data objectForKey:@"error"]] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
            [self dismissModalViewControllerAnimated:YES];
        }
        [data release];
    }
}

#pragma mark 自定义初始化
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        [self navigationItem].title = @"发布记录";
        txtView=[[UITextView alloc] initWithFrame:CGRectMake(30, 30, self.view.bounds.size.width-60, (self.view.bounds.size.height-200)/2)];
        txtView.backgroundColor = [UIColor grayColor];
        [self.view addSubview:txtView];
        [txtView release];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width-80, self.view.bounds.size.height/2-50, 60, 40) withTitle:@"发送" andTag:1 andAction:@selector(PushStatusAction:)];
        [self addButtonInFrame:CGRectMake(30, self.view.bounds.size.height/2-50, 60, 40) withTitle:@"取消" andTag:2 andAction:@selector(CancelPushStatus:)];
        
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
