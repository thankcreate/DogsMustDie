//
//  KaixinMainViewController.m
//  KaixinApiDemo
//
//  Created by 左 顺兴 on 12-4-23.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "KaixinMainViewController.h"
#import "MobiSageSDK.h"
#import "MSKaixinPageAddFan.h"
#import "JSONKit.h"
#import "Utility.h"
#import "KaixinSendRecordController.h"
#import "KaixinAlbumController.h"

@implementation KaixinMainViewController

#pragma mark 创建UIButton
-(void) addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

#pragma mark 添加关注
-(void)MakeFriends:(id)sender
{
    //相应对象，同样根据令牌创建
    MSKaixinPageAddFan * pagebecomefanPackage = [[MSKaixinPageAddFan alloc] initWithAppKey:KaixinApp_Key AccessToken:[[Utility getInstance] kaixin_AccessToken]];
    //关注参数
    [pagebecomefanPackage addParameter:@"pageid" Value:[pageidtxt text]];
    //完成后消息
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onMobiSagePackageFinish:) name:MobiSagePackage_Finish object:pagebecomefanPackage];
    //发送
    [[MobiSageManager getInstance] pushMobiSagePackage:pagebecomefanPackage];
    MSSafeRelease(pagebecomefanPackage);
}

#pragma mark 完成后消息
-(void)onMobiSagePackageFinish:(NSNotification*) notify
{
    //线程安全的调用
    [self performSelectorOnMainThread:@selector(PerformMobiSagePackageFinish:) withObject:notify waitUntilDone:NO];
}

#pragma mark 完成后方法
-(void)PerformMobiSagePackageFinish:(NSNotification*) notify
{
    //判断消息类型
    if ([[notify object] isKindOfClass:[MSKaixinPageAddFan class]]) {
        //获取参数
        MSKaixinPageAddFan * package= (MSKaixinPageAddFan *)[notify object];
        //解析
        NSDictionary * Data = [[[JSONDecoder decoder] objectWithData:package->resultData] retain]; 
        NSLog(@"resultData is:%@",Data);
        NSLog(@"error_code is:%@",[Data objectForKey:@"error_code"]);
        NSLog(@"error is:%@",[Data objectForKey:@"error"]);
        //判断消息类型并出示相应提示
        if ([[Data objectForKey:@"result"] intValue] == 1) {
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:@"加关注成功" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
            [alertView release];
        }
        else if ([[Data objectForKey:@"error_code"] intValue] == 400)
        {
            UIAlertView * alertView =[[UIAlertView alloc]initWithTitle:nil message:[NSString stringWithFormat:@"加关注失败，%@",[Data objectForKey:@"error"]] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
        }
        else
        {
            NSLog(@"%@",[[Data objectForKey:@"error_code"] class]);
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:@"加关注失败" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
        }
    }
    
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isKindOfClass: [UIButton class]] )
    {    
        return NO;
    }
    return YES;
}

-(void)done:(id)sender
{  
    for (UIView *view in self.view.subviews)
    {  
        if ([view isKindOfClass:[UITextField class]]) 
        {  
            [view resignFirstResponder];
            
        }
    }
}

#pragma mark 发微博
-(void)SendRecord:(id)sender
{
    KaixinSendRecordController * send = [KaixinSendRecordController new];
    [[self navigationController] pushViewController:send animated:YES];
    [send release];

}

#pragma mark 相册
-(void)Album:(id)sender
{
    KaixinAlbumController * album = [[KaixinAlbumController alloc] init];
    [[self navigationController] pushViewController:album animated:YES];
    [album release];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.navigationItem.title = @"功能界面";
        [[self view] setBackgroundColor:[UIColor whiteColor]];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2-65, 90, 50) withTitle:@"关注" andTag:1 andAction:@selector(MakeFriends:)];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2+15, 90, 50) withTitle:@"发记录" andTag:1 andAction:@selector(SendRecord:)];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2+95, 90, 50) withTitle:@"相册" andTag:1 andAction:@selector(Album:)];
        UILabel* pageid=[[[UILabel alloc]initWithFrame:CGRectMake(30, 30, 90, 40)]autorelease];
        pageidtxt=[[[UITextField alloc]initWithFrame:CGRectMake(150, 30, 150, 40)]autorelease];
        [pageid setText:@"PageID:"];
        [pageidtxt setBorderStyle:UITextBorderStyleLine];
        [pageidtxt setText:@"76025941"];
        [self.view addSubview:pageidtxt];
        [self.view addSubview:pageid];

    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(done:)];
    tapGestureRecognizer.numberOfTapsRequired = 1;
    tapGestureRecognizer.delegate=self;
    [self.view addGestureRecognizer: tapGestureRecognizer];   //只需要点击非文字输入区域就会响应hideKeyBoard  
    [tapGestureRecognizer release];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
