//
//  KaixinPhotoUploadController.m
//  KaixinApiDemo
//
//  Created by 左 顺兴 on 12-4-27.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "KaixinPhotoUploadController.h"
#import "MobiSageSDK.h"
#import "MSKaixinPhotoUpload.h"
#import "JSONKit.h"
#import "Utility.h"


@implementation KaixinPhotoUploadController
#pragma mark 创建UIButton
-(void) addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

-(void)selectImg:(id)sender
{
    //点击按钮选择照片
    NSLog(@"%@",NSStringFromSelector(_cmd));
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        UIImagePickerController * picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        
        if (isPad) {
            popoverController = [[UIPopoverController alloc] initWithContentViewController:picker];;
            [popoverController presentPopoverFromRect:CGRectMake(0, 0, 300, 300) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            [picker release];
        }else {
            [self presentModalViewController:picker animated:YES];
            [picker release];
        }
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"连接到图片库错误"
                              message:@""
                              delegate:nil
                              cancelButtonTitle:@"确定"
                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
    
}

-(void)uploadImg:(id)sender
{
    if (imageFilePath == nil || [imageFilePath isEqualToString:@""]) {
        UIAlertView *alertView =[[UIAlertView alloc] initWithTitle:nil message:@"请先选择照片" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alertView show];
        [alertView release];
        return;
    }
    //点击按钮开始上传
    MSKaixinPhotoUpload * kaixinPhotosGetAlbums = [[MSKaixinPhotoUpload alloc] initWithAppKey:KaixinApp_Key AccessToken:[[Utility getInstance] kaixin_AccessToken]];
    [kaixinPhotosGetAlbums addParameter:@"albumid" Value:[[Utility getInstance] kaixin_AlbumID]];
    [kaixinPhotosGetAlbums addParameter:@"pic" Value:imageFilePath];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onMobiSagePackageFinish:) name:MobiSagePackage_Finish object:kaixinPhotosGetAlbums];
    [[MobiSageManager getInstance] pushMobiSagePackage:kaixinPhotosGetAlbums];
    MSSafeRelease(kaixinPhotosGetAlbums);
}

//完成后消息
-(void)onMobiSagePackageFinish:(NSNotification*) notify
{
    //线程安全调用方法
    [self performSelectorOnMainThread:@selector(PerformMobiSagePackageFinish:) withObject:notify waitUntilDone:NO];
}

//消息完成后的处理
-(void)PerformMobiSagePackageFinish:(NSNotification*) notify
{
    if ([[notify object] isKindOfClass:[MSKaixinPhotoUpload class]]) {
        MSKaixinPhotoUpload * package= (MSKaixinPhotoUpload*)[notify object];
        NSDictionary * resultData=[[[JSONDecoder decoder]objectWithData:package->resultData] retain];
        NSLog(@"resultData is:%@",resultData);
        NSLog(@"error_code is:%@",[resultData objectForKey:@"error_code"]);
        NSLog(@"error is:%@",[resultData objectForKey:@"error"]);
        //判断消息类型并处理
        if ([resultData objectForKey:@"error"] == nil) {
            UIAlertView *alertView =[[UIAlertView alloc] initWithTitle:nil message:@"成功" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
            [self dismissModalViewControllerAnimated:YES];
        }
        else
        {
            
            UIAlertView * alertView =[[UIAlertView alloc]initWithTitle:nil message:[NSString stringWithFormat:@"失败，%@",[resultData objectForKey:@"error"]] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
            [self dismissModalViewControllerAnimated:YES];
        }
        [resultData release];
    }
}

- (NSString *)getImageFilePath
{
    NSArray * paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString * documentsDirectory = [paths objectAtIndex:0];
    return [documentsDirectory stringByAppendingPathComponent:@"image.png"];
}

- (id)init
{
    self = [super init];
    if (self) {
        // Custom initialization
        [self navigationItem].title = @"上传照片";
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-120, 240, 80, 30) withTitle:@"选择" andTag:0 andAction:@selector(selectImg:)];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2+40, 240, 80, 30) withTitle:@"上传" andTag:1 andAction:@selector(uploadImg:)];
        imgView = [[UIImageView alloc] initWithFrame:CGRectMake(self.view.bounds.size.width/2-100, 20, 200, 200)];
        imgView.backgroundColor = [UIColor grayColor];
        [self.view addSubview:imgView];
        imageFilePath = [[self getImageFilePath] retain];
    }
    return self;

}

- (BOOL)writeImage:(UIImage*)image
{
    if ((image == nil) || (imageFilePath == nil) || ([imageFilePath isEqualToString:@""]))
        return NO;
    @try
    {
        NSData *imageData = nil;
        NSString *ext = [imageFilePath pathExtension];
        if ([ext isEqualToString:@"png"])
        {
            imageData = UIImagePNGRepresentation(image);
        }
        else
        {
            // the rest, we write to jpeg
            // 0. best, 1. lost. about compress.
            imageData = UIImageJPEGRepresentation(image, 0);
        }
        
        if ((imageData == nil) || ([imageData length] <= 0))
            return NO;
        
        [imageData writeToFile:imageFilePath atomically:YES];
        return YES;
    }
    @catch (NSException *e)
    {
        NSLog(@"create thumbnail exception.");
    }
    return NO;
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
    [imgView setImage:image];
    if (isPad) {
        [popoverController dismissPopoverAnimated:YES];
    } else {
        [picker dismissModalViewControllerAnimated:YES];
    }
    //苹果不提供路径，所以只能自己先存起来，从而拿到路径
    if ([self writeImage:image]) {
        NSLog(@"Save Image Success!!!");
    }
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
