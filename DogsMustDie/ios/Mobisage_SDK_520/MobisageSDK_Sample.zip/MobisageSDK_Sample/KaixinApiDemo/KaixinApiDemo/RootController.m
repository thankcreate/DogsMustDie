//
//  RootController.m
//  KaixinApiDemo
//
//  Created by 左 顺兴 on 12-4-23.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "RootController.h"
#import "Utility.h"
#import "KaixinLoginViewController.h"
#import "KaixinMainViewController.h"

@implementation RootController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.navigationItem.title = @"主界面";
        // 因为是测试程序，并未通过开心认证，所以可以授权的账号有限，本程序使用固定测试账号登陆
        [self addLabelInFrame:CGRectMake(30, 30, 260, 30) withTitle:@"请用以下账号登陆" andTag:3];
        [self addLabelInFrame:CGRectMake(30, 70, 260, 30) withTitle:@"用户名:zuo890@163.com" andTag:4];
        [self addLabelInFrame:CGRectMake(30, 110, 260, 30) withTitle:@"密码:1qaz2wsx" andTag:5];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2-65, 90, 50) withTitle:@"登陆" andTag:1 andAction:@selector(KaixinToAccessTokenView:)];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2+15, 90, 50) withTitle:@"退出" andTag:2 andAction:@selector(KaixinLogOut:)];

    }
    return self;
}


-(void)KaixinToAccessTokenView:(id)sender
{
    if ([[Utility getInstance] kaixin_AccessToken]==nil || [[[Utility getInstance] kaixin_AccessToken] isEqualToString:@""]) 
    {
        NSLog(@"=========================accesstoken is %@,goto shouquan page" ,[[Utility getInstance] kaixin_AccessToken]);
        KaixinLoginViewController* kaixinLogincController=[[KaixinLoginViewController alloc] init];
        [[self navigationController] pushViewController:kaixinLogincController animated:YES];
        [kaixinLogincController release];
    }
    else
    {
        NSLog(@"=========================accesstoken is %@,goto main page" ,[[Utility getInstance] kaixin_AccessToken]);
        KaixinMainViewController * kaixinMainView=[[KaixinMainViewController alloc] init];
        [[self navigationController] pushViewController:kaixinMainView animated:YES];
        [kaixinMainView release];
    }
}

-(void)KaixinLogOut:(id)sender
{
    if ([[Utility getInstance] kaixin_AccessToken]!=nil) 
    {
        [[Utility getInstance] setKaixin_AccessToken:@""];
        NSLog(@"=========================after log out accesstoken is %@",[[Utility getInstance] kaixin_AccessToken]);
    }
}

#pragma mark 创建UILabel
- (void)addLabelInFrame:(CGRect)frame withTitle:(NSString*)title andTag:(NSInteger)tag
{
    UILabel* label = [UILabel new];
    [label setFrame:frame];
    [label setText:title];
    [label setTextAlignment:UITextAlignmentCenter];
    [label setTag:tag];
    [label setTextAlignment:UITextAlignmentLeft];
    [self.view addSubview:label];
    MSSafeRelease(label);
}

#pragma mark创建UIButton
- (void)addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

@end
