//
//  KaixinLoginViewController.m
//  KaixinApiDemo
//
//  Created by 左 顺兴 on 12-4-23.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "KaixinLoginViewController.h"
#import "KaixinMainViewController.h"
#import "MSKaixinAccessToken.h"
#import "MSKaixinAuthorize.h"
#import "MobiSageSDK.h"
#import "JSONKit.h"
#import "Utility.h"

@implementation KaixinLoginViewController

-(NSURLRequest*)getAuthorizeRequest
{
    MSKaixinAuthorize * authorize = [[MSKaixinAuthorize alloc] initWithAppKey:KaixinApp_Key];
    //申请除基本权限之外发布微博和照片等的权限
    [authorize addParameter:@"scope" Value:@"create_records user_photo friends_photo upload_photo"];
    NSMutableURLRequest * request = [[authorize createURLRequest] retain];
    
    [authorize release];
    return [request autorelease];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.navigationItem.title = @"登陆界面";
        UIWebView *kaixinwebview= [UIWebView new];
        [kaixinwebview setFrame:self.view.frame];
        kaixinwebview.delegate = self;
        [self.view addSubview:kaixinwebview];
        [[self.view.subviews objectAtIndex:0] loadRequest:[self getAuthorizeRequest]];
    }
    return self;
}

#pragma mark webview的委托方法：请求结束后调用此方法
-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSLog(@"request:%@",request);
    //获取服务器返回的字符串
    NSString* queryText = [[request URL] query];
    //若字符串为空则返回
    if(queryText == nil)
        return YES;
    
    //根据等号分割字符串
    NSArray* kvText = [queryText componentsSeparatedByString:@"="];
    if([[kvText objectAtIndex:0] isEqualToString:@"code"])
    {
        //根据注册的 Appkey 和 AppSecret 创建令牌对象
        MSKaixinAccessToken * TokenPackage = [[MSKaixinAccessToken alloc] 
                                              initWithAppKey:KaixinApp_Key 
                                              Secret:KaixinApp_Secret 
                                              Code:[kvText objectAtIndex:1]];
        
        //注册 MobiSagePackage_Finish 消息
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAccessTokenMobiSagePackageFinish:) name:MobiSagePackage_Finish object:TokenPackage];
        //将 TokenPackage Push进MabiSageManager
       [[MobiSageManager getInstance] pushMobiSagePackage:TokenPackage];
        return NO;
    }
    return YES;
    
}

#pragma mark MobiSagePackage_Finish消息的注册方法
-(void)onAccessTokenMobiSagePackageFinish:(NSNotification*)notify
{
    NSError* error = nil;
    MSKaixinPackage * package=(MSKaixinPackage *)[notify object];
    NSLog(@"Status code %d",package->statusCode);
    //使用SDK中的JSON解析库解析数据
    NSDictionary* resultData = [[[JSONDecoder decoder] objectWithData:package->resultData error:&error] retain];
    for (NSInteger index=0; index<[[resultData allKeys]count]; index++) {
        id key=[[resultData allKeys]objectAtIndex:index];
        NSLog(@"Key:%@====Value:%@",key,[resultData objectForKey:key]);
    }
    //获取token并存储，此处在实际项目中建议本地存储
    [[Utility getInstance] setKaixin_AccessToken:[resultData objectForKey:@"access_token"]];
    NSString * uid = [[[resultData objectForKey:@"access_token"] componentsSeparatedByString:@"_"] objectAtIndex:0];
    [[Utility getInstance] setKaixin_UID:uid];
    //切记释放
    [resultData release];
    
    KaixinMainViewController* kaixinMainView = [KaixinMainViewController new];
    [[self navigationController] pushViewController:kaixinMainView animated:YES];
    [kaixinMainView release];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
