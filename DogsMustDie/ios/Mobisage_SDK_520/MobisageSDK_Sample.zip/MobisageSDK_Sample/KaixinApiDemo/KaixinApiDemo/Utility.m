//
//  Utility.m
//  KaixinApiDemo
//
//  Created by 左 顺兴 on 12-4-23.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "Utility.h"

@implementation Utility

@synthesize kaixin_AccessToken,kaixin_UID,kaixin_AlbumID;

static Utility* utility_Instance = nil;

+(Utility*)getInstance
{
    @synchronized(self)
    {
        if(utility_Instance == nil)
        {
            utility_Instance = [Utility new];
        }
    }
    return utility_Instance;
}

@end
