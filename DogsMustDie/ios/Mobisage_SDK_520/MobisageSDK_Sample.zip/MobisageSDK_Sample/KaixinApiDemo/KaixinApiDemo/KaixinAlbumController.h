//
//  KaixinAlbumController.h
//  KaixinApiDemo
//
//  Created by 左 顺兴 on 12-4-25.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KaixinAlbumController : UIViewController<UINavigationControllerDelegate, UIImagePickerControllerDelegate>
{
    UIImageView * imgView;
}
@end
