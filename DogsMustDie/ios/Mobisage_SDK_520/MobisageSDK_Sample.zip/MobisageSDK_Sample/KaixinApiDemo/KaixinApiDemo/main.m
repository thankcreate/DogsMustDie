//
//  main.m
//  KaixinApiDemo
//
//  Created by 左 顺兴 on 12-4-23.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "KaixinAppDelegate.h"
#import "MobiSageSDK.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        //此处设置PublishID
        [[MobiSageManager getInstance] setPublisherID:MobiSage_PublisherId_Test];
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([KaixinAppDelegate class]));
    }
}
