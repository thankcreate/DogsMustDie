//
//  Utility.h
//  KaixinApiDemo
//
//  Created by 左 顺兴 on 12-4-23.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <Foundation/Foundation.h>

//本程序在开心注册的AppID、App_Key、App_Secret
#define KaixinAppID                     @"100031766"
#define KaixinApp_Key                   @"414437219619ec1c389c294004154904"
#define KaixinApp_Secret                @"7657c3696c05cd0edbf4c5577e0edf1d"

//用来释放内存
#ifndef MSSafeRelease
#define MSSafeRelease(obj) if(obj!=nil){[obj release]; obj=nil;}
#endif

#define isPad (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)

//开心微博相关公共类
@interface Utility : NSObject
{
    //用来存储授权之后的Token，实际使用中建议本地存储
    NSString * kaixin_AccessToken;
    NSString * kaixin_UID;
    NSString * kaixin_AlbumID;
}
@property(nonatomic,copy)NSString * kaixin_AccessToken;
@property(nonatomic,copy)NSString * kaixin_UID;
@property(nonatomic,copy)NSString * kaixin_AlbumID;
//获取实例
+(Utility*)getInstance;
@end
