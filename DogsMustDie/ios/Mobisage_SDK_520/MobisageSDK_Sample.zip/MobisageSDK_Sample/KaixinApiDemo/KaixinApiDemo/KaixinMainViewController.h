//
//  KaixinMainViewController.h
//  KaixinApiDemo
//
//  Created by 左 顺兴 on 12-4-23.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KaixinMainViewController : UIViewController<UIGestureRecognizerDelegate>
{
    UITextField* pageidtxt;
}
@end
