//
//  KaixinAlbumController.m
//  KaixinApiDemo
//
//  Created by 左 顺兴 on 12-4-25.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "KaixinAlbumController.h"
#import "MobiSageSDK.h"
#import "MSKaixinAlbumShow.h"
#import "JSONKit.h"
#import "Utility.h"

#import "KaixinPhotoUploadController.h"

@implementation KaixinAlbumController
#pragma mark 创建UIButton
- (void)addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

//完成后消息
-(void)onMobiSagePackageFinish:(NSNotification*) notify
{
    //线程安全调用方法
    [self performSelectorOnMainThread:@selector(PerformMobiSagePackageFinish:) withObject:notify waitUntilDone:NO];
}

//消息完成后的处理
-(void)PerformMobiSagePackageFinish:(NSNotification*) notify
{
    if ([[notify object] isKindOfClass:[MSKaixinAlbumShow class]]) {
        MSKaixinAlbumShow * package= (MSKaixinAlbumShow*)[notify object];
        NSDictionary * resultData=[[[JSONDecoder decoder]objectWithData:package->resultData] retain];
        NSArray * dataArray = [resultData objectForKey:@"data"];
        NSLog(@"resultData is:%@",resultData);
        NSLog(@"dataArray is:%@",dataArray);
        for (NSDictionary * item in dataArray) {
            NSLog(@"item is:%@",item);
            [[Utility getInstance] setKaixin_AlbumID:[item objectForKey:@"albumid"]];
            NSString * url = [item objectForKey:@"coverpic"];
            NSData * imageData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:url]];
            UIImage * image = [[UIImage alloc] initWithData:imageData];
            [imgView setImage:image];
            [imageData release];
            [image release];
        }
        [resultData release];
    }
}

- (void)onRefresh:(id)sender
{
    MSKaixinAlbumShow * albumShow = [[MSKaixinAlbumShow alloc] initWithAppKey:KaixinApp_Key AccessToken:[[Utility getInstance] kaixin_AccessToken]];
    //若参数uid缺失，默认使用当前登陆用户的UID
    [albumShow addParameter:@"uid" Value:[[Utility getInstance] kaixin_UID]];
    //起始值，这里设置的是从零开始
    [albumShow addParameter:@"start" Value:@"0"];
    //返回数量，这里设置了100个
    [albumShow addParameter:@"num" Value:@"100"];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onMobiSagePackageFinish:) name:MobiSagePackage_Finish object:albumShow];
    [[MobiSageManager getInstance] pushMobiSagePackage:albumShow];
    MSSafeRelease(albumShow);
}

- (void)onUpload:(id)sender
{
    if ([[Utility getInstance] kaixin_AlbumID] == nil) {
        UIAlertView *alertView =[[UIAlertView alloc] initWithTitle:nil message:@"请先刷新照片专辑" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    KaixinPhotoUploadController * upload = [[KaixinPhotoUploadController alloc] init];
    [self.navigationController pushViewController:upload animated:YES];
    [upload release];
}

- (id)init
{
    self = [super init];
    if (self) {
        self.navigationItem.title = @"AlbumShow";
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-100, 10, 60, 30) withTitle:@"刷新" andTag:0 andAction:@selector(onRefresh:)];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2+40, 10, 60, 30) withTitle:@"上传" andTag:0 andAction:@selector(onUpload:)];
        imgView = [[UIImageView alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
        imgView.backgroundColor = [UIColor grayColor];
        [self.view addSubview:imgView];
        [imgView release];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView
 {
 }
 */

/*
 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad
 {
 [super viewDidLoad];
 }
 */

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
@end
