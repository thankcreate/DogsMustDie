//
//  rootController.h
//  MobiSageAdBannerDemo
//
//  Created by 左 顺兴 on 12-4-5.
//  Copyright (c) 2012年 APP. All rights reserved.
//

#import <UIKit/UIKit.h>


#import "MobiSageSDK.h"

@interface rootController : UIViewController <MobiSageAdViewDelegate>

@end
