//
//  SampleAppDelegate.m
//  MobiSageAdBannerDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "SampleAppDelegate.h"
#import "rootController.h"

@implementation SampleAppDelegate

@synthesize window = _window;

- (void)dealloc
{
    [_window release];
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    
    rootController * root = [[rootController alloc] init];
    self.window.rootViewController = root;
    
    [self.window makeKeyAndVisible];
    return YES;
}

@end
