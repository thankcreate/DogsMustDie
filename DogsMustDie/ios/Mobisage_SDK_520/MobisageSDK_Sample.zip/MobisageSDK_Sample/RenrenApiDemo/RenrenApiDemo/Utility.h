//
//  Utility.h
//  SNSDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <Foundation/Foundation.h>

//授权地址
#define RenRen_Weibo_Authorize @"https://graph.renren.com/oauth/authorize?client_id=%@&redirect_uri=http://graph.renren.com/oauth/login_success.html&display=touch&response_type=code&scope=read_user_status,read_user_album,publish_feed,status_update,photo_upload&state=&x_renew=true"
//本程序在人人注册的App_Key、App_Secret
#define RenRenApp_Key                  @"27f3f9a773bd4e18a2ad95cc55d6e948"
#define RenRenApp_Secret               @"e07b0348f0d54f65a2bb3ae3fd8a78e4"

//用来释放内存
#ifndef MSSafeRelease
#define MSSafeRelease(obj) if(obj!=nil){[obj release]; obj=nil;}
#endif


//人人微博相关公共类
@interface Utility : NSObject
{
    //用来存储授权之后的Token，实际使用中建议本地存储
    NSString* renren_AccessToken;    
}
@property(nonatomic,copy)NSString* renren_AccessToken;
//获取实例
+(Utility*)getInstance;
@end
