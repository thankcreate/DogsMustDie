//
//  RenRenMainViewController.m
//  Main
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "RenRenMainViewController.h"
#import "RenRenUpdateStatusViewController.h"
#import "Utility.h"
#import "MobiSageSDK.h"
#import "JSONKit.h"
#import "MSRenrenPagesBecomeFan.h"

@implementation RenRenMainViewController

#pragma mark 创建UIButton
-(void) addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

#pragma mark 添加关注
-(void)MakeFriends:(id)sender
{
    //相应对象，同样根据令牌创建
    MSRenrenPagesBecomeFan *pagebecomefanPackage=[[MSRenrenPagesBecomeFan alloc] initWithAccessToken:[[Utility getInstance]renren_AccessToken] SecretKey:RenRenApp_Secret clientID:RenRenApp_Key];
    //关注参数
    [pagebecomefanPackage addParameter:@"page_id" Value:[pageidtxt text]];
    //完成后消息
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onMobiSagePackageFinish:) name:MobiSagePackage_Finish object:pagebecomefanPackage];
    //发送
    [[MobiSageManager getInstance] pushMobiSagePackage:pagebecomefanPackage];
    MSSafeRelease(pagebecomefanPackage);
}

#pragma mark 完成后消息
-(void)onMobiSagePackageFinish:(NSNotification*) notify
{
    //线程安全的调用
    [self performSelectorOnMainThread:@selector(PerformMobiSagePackageFinish:) withObject:notify waitUntilDone:NO];
}

#pragma mark 完成后方法
-(void)PerformMobiSagePackageFinish:(NSNotification*) notify
{
    //判断消息类型
    if ([[notify object] isKindOfClass:[MSRenrenPagesBecomeFan class]]) {
        //获取参数
        MSRenrenPagesBecomeFan *package= (MSRenrenPagesBecomeFan*)[notify object];
        //解析
        NSDictionary* Data = [[[JSONDecoder decoder] objectWithData:package->resultData] retain]; 
        NSLog(@"%@",Data);
        //判断消息类型并出示相应提示
        if ([Data objectForKey:@"result"]==[NSNumber numberWithInt:1]) {
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:@"加关注成功" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
            [alertView release];
        }
        else if ([[Data objectForKey:@"error_code"] isEqualToNumber:[NSNumber numberWithInt:20310]])
        {
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:@"加关注失败,对同一账户，一天之内只能加关注一次！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
        }
        else
        {
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:[Data objectForKey:@"error_msg"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alertView show];
            [alertView release];
        }
    }
}

#pragma mark 发微博
-(void)UpdataStatus:(id)sender
{
    RenRenUpdateStatusViewController *updateStatusView=[RenRenUpdateStatusViewController new];
    [self presentModalViewController:updateStatusView animated:YES];
    [updateStatusView release];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isKindOfClass: [UIButton class]] )
    {    
        return NO;
    }
    return YES;
}

-(void)done:(id)sender  
{  
    for (UIView *view in self.view.subviews)
    {  
        if ([view isKindOfClass:[UITextField class]]) 
        {  
            [view resignFirstResponder];  
            
        }  
    }  
}

#pragma mark 自定义初始化
- (id)init
{
    self = [super init];
    if (self) {
        // Custom initialization
        [[self view] setBackgroundColor:[UIColor whiteColor]];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2-65, 90, 50) withTitle:@"加关注" andTag:1 andAction:@selector(MakeFriends:)];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2+15, 90, 50) withTitle:@"发微博" andTag:1 andAction:@selector(UpdataStatus:)];
        UILabel* pageid=[[[UILabel alloc]initWithFrame:CGRectMake(30, 30, 90, 40)]autorelease];
        pageidtxt=[[[UITextField alloc]initWithFrame:CGRectMake(150, 30, 150, 40)]autorelease];
        [pageid setText:@"PageID:"];
        [pageidtxt setBorderStyle:UITextBorderStyleLine];
        [pageidtxt setText:@"699901400"];
        [self.view addSubview:pageidtxt];
        [self.view addSubview:pageid];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView
 {
 }
 */

/*
 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad
 {
 [super viewDidLoad];
 }
 */

-(void)viewDidLoad
{
    [super viewDidLoad];
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(done:)];
    tapGestureRecognizer.numberOfTapsRequired = 1;
    tapGestureRecognizer.delegate=self;
    [self.view addGestureRecognizer: tapGestureRecognizer];   //只需要点击非文字输入区域就会响应hideKeyBoard  
    [tapGestureRecognizer release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
//{
//    // Return YES for supported orientations
//    return (interfaceOrientation == UIInterfaceOrientationPortrait);
//}

@end
