//
//  Utility.m
//  SNSDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "Utility.h"


@implementation Utility

@synthesize renren_AccessToken;

static Utility* utility_Instance = nil;

+(Utility*)getInstance
{
    @synchronized(self)
    {
        if(utility_Instance == nil)
        {
            utility_Instance = [Utility new];
        }
    }
    return utility_Instance;
}

@end
