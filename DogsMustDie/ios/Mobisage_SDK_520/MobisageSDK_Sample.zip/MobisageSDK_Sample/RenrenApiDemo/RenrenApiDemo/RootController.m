//
//  RootController.m
//  RenrenApiDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "RootController.h"
#import "RenRenMainViewController.h"
#import "RenRenLoginViewController.h"
#import "Utility.h"

@implementation RootController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // 因为是测试程序，并未通过人人认证，所以可以授权的账号有限，本程序使用固定测试账号登陆
        [self addLabelInFrame:CGRectMake(30, 30, 260, 30) withTitle:@"请用以下账号登陆" andTag:3];
        [self addLabelInFrame:CGRectMake(30, 70, 260, 30) withTitle:@"用户名:ljianshuang@163.com" andTag:4];
        [self addLabelInFrame:CGRectMake(30, 110, 260, 30) withTitle:@"密码:1qaz2wsx" andTag:5];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2-65, 90, 50) withTitle:@"登陆" andTag:1 andAction:@selector(RenRenToAccessTokenView:)];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2+15, 90, 50) withTitle:@"退出" andTag:2 andAction:@selector(RenRenLogOut:)];
    }
    return self;
}

-(void)RenRenToAccessTokenView:(id)sender
{
    if ([[Utility getInstance]renren_AccessToken]==nil || [[[Utility getInstance] renren_AccessToken] isEqualToString:@""] ) 
    {
        NSLog(@"=========================accesstoken is %@,goto shouquan page" ,[[Utility getInstance] renren_AccessToken]);
        RenRenLoginViewController* renrenLogincController=[[RenRenLoginViewController alloc]init];
        [[self navigationController] pushViewController:renrenLogincController animated:YES];
        [renrenLogincController release];
    }
    else
    {
        NSLog(@"=========================accesstoken is %@,goto main page" ,[[Utility getInstance] renren_AccessToken]);
        RenRenMainViewController* renrenMainView=[[RenRenMainViewController alloc]init];
        [[self navigationController]pushViewController:renrenMainView animated:YES];
        [renrenMainView release];
    }
}

-(void)RenRenLogOut:(id)sender
{
    if ([[Utility getInstance] renren_AccessToken]!=nil) 
    {
        [[Utility getInstance]setRenren_AccessToken:@""];
        NSLog(@"=========================after log out accesstoken is %@",[[Utility getInstance] renren_AccessToken]);
    }
}

#pragma mark 创建UILabel
- (void)addLabelInFrame:(CGRect)frame withTitle:(NSString*)title andTag:(NSInteger)tag
{
    UILabel* label = [UILabel new];
    [label setFrame:frame];
    [label setText:title];
    [label setTextAlignment:UITextAlignmentCenter];
    [label setTag:tag];
    [label setTextAlignment:UITextAlignmentLeft];
    [self.view addSubview:label];
    MSSafeRelease(label);
}

#pragma mark创建UIButton
- (void)addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
