//
//  RenRenLoginViewController.h
//  Main
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RenRenLoginViewController : UIViewController<UIWebViewDelegate>

@end
