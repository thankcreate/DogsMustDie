//
//  RenRenLoginViewController.m
//  Main
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "RenRenLoginViewController.h"
#import "RenRenMainViewController.h"
#import "MobiSageSDK.h"
#import "JSONKit.h"
#import "MSRenrenToken.h"
#import "Utility.h"

@implementation RenRenLoginViewController

#pragma mark 根据RenRen_Weibo_Authorize,RenRenApp_Key创建renren服务器的URL
-(NSURLRequest*)getAuthorizeRequest
{
    NSMutableURLRequest* request = [[NSMutableURLRequest alloc] initWithURL:
                                    [NSURL URLWithString:[NSString stringWithFormat:RenRen_Weibo_Authorize,RenRenApp_Key]]];
    [request setHTTPMethod:@"POST"];
    return [request autorelease];
}

#pragma mark webview的委托方法：请求结束后调用此方法
-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    //获取服务器返回的字符串
    NSString* queryText = [[request URL] query];
    //若字符串为空则返回
    if(queryText == nil)
        return YES;
    
    //根据等号分割字符串
    NSArray* kvText = [queryText componentsSeparatedByString:@"="];
    NSLog(@"Code is:%@",[kvText objectAtIndex:1]);
    if([[kvText objectAtIndex:0] isEqualToString:@"code"])
    {
        //根据注册的 Appkey 和 AppSecret 创建令牌对象
        MSRenrenToken *TokenPackage= [[MSRenrenToken alloc]initWithClientID:RenRenApp_Key ClientSecret:RenRenApp_Secret Code:[kvText objectAtIndex:1]];
        //注册 MobiSagePackage_Finish 消息
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAccessTokenMobiSagePackageFinish:) name:MobiSagePackage_Finish object:TokenPackage];
        //将 TokenPackage Push进MabiSageManager
        [[MobiSageManager getInstance] pushMobiSagePackage:TokenPackage];
        return NO;
    }
    return YES;
    
}

#pragma mark MobiSagePackage_Finish消息的注册方法
-(void)onAccessTokenMobiSagePackageFinish:(NSNotification*)notify
{
    NSError* error = nil;
    MSRenrenToken *package=(MSRenrenToken*)[notify object];
    NSLog(@"Status code %d",package->statusCode);
    //使用SDK中的JSON解析库解析数据
    NSDictionary* resultData = [[[JSONDecoder decoder] objectWithData:package->resultData error:&error] retain];
    for (NSInteger index=0; index<[[resultData allKeys]count]; index++) {
        id key=[[resultData allKeys]objectAtIndex:index];
        NSLog(@"Key:%@====Value:%@",key,[resultData objectForKey:key]);
    }
    NSLog(@"AccessToken %@",[resultData objectForKey:@"access_token"]);
    //获取token并存储，此处在实际项目中建议本地存储
    [[Utility getInstance]setRenren_AccessToken:[resultData objectForKey:@"access_token"]];
    //切记释放
    [resultData release];
    
    RenRenMainViewController* renrenMainView=[RenRenMainViewController new];
    [[self navigationController] pushViewController:renrenMainView animated:YES];
    [renrenMainView release];
}

#pragma mark 自定义初始化方法
- (id)init
{
    self = [super init];
    if (self) {
        [[self view]setBackgroundColor:[UIColor whiteColor]];
        // Custom initialization
    }
    UIWebView *renrenwebview= [UIWebView new];
    [renrenwebview setFrame:self.view.frame];
    renrenwebview.delegate = self;
    [self.view addSubview:renrenwebview];
    [[self.view.subviews objectAtIndex:0] loadRequest:[self getAuthorizeRequest]];
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
