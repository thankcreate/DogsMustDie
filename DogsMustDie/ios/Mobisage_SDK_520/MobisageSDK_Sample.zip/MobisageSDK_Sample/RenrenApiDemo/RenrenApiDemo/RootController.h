//
//  RootController.h
//  RenrenApiDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootController : UIViewController

- (void)addLabelInFrame:(CGRect)frame withTitle:(NSString*)title andTag:(NSInteger)tag;
- (void)addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action;

@end
