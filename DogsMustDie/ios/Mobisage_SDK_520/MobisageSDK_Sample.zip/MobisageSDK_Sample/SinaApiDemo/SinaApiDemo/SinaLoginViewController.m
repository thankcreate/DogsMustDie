//
//  SinaLoginViewController.m
//  SNSDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "SinaLoginViewController.h"
#import "SinaMainViewController.h"
#import "MSSinaAccessToken.h"
#import "MobiSageSDK.h"
#import "JSONKit.h"
#import "Utility.h"

@implementation SinaLoginViewController

#pragma mark 请求新浪服务器，获取授权的web代码
-(NSURLRequest*)getAuthorizeRequest
{
    NSMutableURLRequest* request = [[NSMutableURLRequest alloc] initWithURL:
                                    [NSURL URLWithString:[NSString stringWithFormat:Sina_Weibo_Authorize,SinaApp_Key]]];
    [request setHTTPMethod:@"POST"];
    return [request autorelease];
}

#pragma mark 自定义初始化方法
- (id)init
{
    self = [super init];
    if (self) {
        [[self view] setBackgroundColor:[UIColor whiteColor]];
    }
    //创建UIWebView作为新浪微博的载体
    UIWebView *sinawebview= [UIWebView new];
    
    //设置webview的frame
    [sinawebview setFrame:self.view.frame];
    
    //给webview的委托赋值，将当前controller赋值给webview的委托
    //这一步很重要，否则无法接收webview的委托方法
    sinawebview.delegate = self;
    
    [self.view addSubview:sinawebview];
    //开始请求
    [[self.view.subviews objectAtIndex:0] loadRequest:[self getAuthorizeRequest]];
    return self;
}

#pragma mark webview的委托方法：请求结束后调用此方法
-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    //获取服务器返回的字符串
    NSString* queryText = [[request URL] query];
    //若字符串为空则返回
    if(queryText == nil)
    {
        return YES;
    }
    NSLog(@"queryText:%@",queryText);
    //根据等号分割字符串
    NSArray* kvText = [queryText componentsSeparatedByString:@"="];
    NSLog(@"kvText:%@",kvText);
    if([[kvText objectAtIndex:0] isEqualToString:@"code"])
    {
        //根据在新浪注册的 Appkey 和 AppSecret 创建令牌对象
        MSSinaAccessToken *TokenPackage= [[MSSinaAccessToken alloc]initWithAppKey:SinaApp_Key Secret:SinaApp_Secret];
        //创建参数字典
        NSMutableDictionary* paramInfo = [NSMutableDictionary new];
        [paramInfo setObject:@"http://sina.com" forKey:@"redirect_uri"];
        [paramInfo setObject:[kvText objectAtIndex:1] forKey:@"code"];
        
        for(id key in [paramInfo allKeys])
        {
            [TokenPackage addParameter:key Value:[paramInfo objectForKey:key]];
        }
        //释放 paramInfo
        MSSafeRelease(paramInfo);
        //注册 MobiSagePackage_Finish 消息
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAccessTokenMobiSagePackageFinish:) name:MobiSagePackage_Finish object:TokenPackage];
        //将 TokenPackage Push进MabiSageManager
        [[MobiSageManager getInstance] pushMobiSagePackage:TokenPackage];
        return NO;
    }
    return YES;
}

#pragma mark MobiSagePackage_Finish消息的注册方法
-(void)onAccessTokenMobiSagePackageFinish:(NSNotification*)notify
{
    NSError* error = nil;
    MSSinaAccessToken *package=(MSSinaAccessToken*)[notify object];
    NSDictionary* resultData = [[[JSONDecoder decoder] objectWithData:package->resultData error:&error] retain];
    if (package->statusCode != 200) {
        NSLog(@"Status code %d",package->statusCode);
        return;
    }
    [[Utility getInstance] setSina_AccessToken:[resultData objectForKey:@"access_token"]];
    [resultData release];
    SinaMainViewController *sinaMainView=[[SinaMainViewController alloc]init];
    [[self navigationController]pushViewController:sinaMainView animated:YES];
    [sinaMainView release];
    
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
