//
//  Utility.h
//  SNSDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import <Foundation/Foundation.h>
//授权地址
#define Sina_Weibo_Authorize      @"https://api.weibo.com/oauth2/authorize?client_id=%@&redirect_uri=http://sina.com&display=mobile&response_type=code"
//本程序在新浪注册的App_Key、App_Secret
#define SinaApp_Key               @"4248479246"
#define SinaApp_Secret            @"2b400db6c8ce0da4fbfd8d5ad00fe269"

//用来释放内存
#ifndef MSSafeRelease
#define MSSafeRelease(obj) if(obj!=nil){[obj release]; obj=nil;}
#endif

//新浪微博相关公共类
@interface Utility : NSObject
{
    //用来存储授权之后的Token，实际使用中建议本地存储
    NSString* sina_AccessToken;
}
@property(nonatomic,copy)NSString* sina_AccessToken;

//获取实例
+(Utility*)getInstance;

@end
