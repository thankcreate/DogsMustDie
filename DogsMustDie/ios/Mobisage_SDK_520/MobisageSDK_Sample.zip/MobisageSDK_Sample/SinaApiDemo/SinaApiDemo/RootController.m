//
//  RootController.m
//  SinaApiDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "RootController.h"
#import "SinaMainViewController.h"
#import "SinaLoginViewController.h"
#import "Utility.h"

@implementation RootController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // 因为是测试程序，并未通过新浪认证，所以可以授权的账号有限，本程序使用固定测试账号登陆
        [self addLabelInFrame:CGRectMake(30, 30, 260, 30) withTitle:@"请用以下账号登陆" andTag:1];
        [self addLabelInFrame:CGRectMake(30, 70, 260, 30) withTitle:@"用户名:yihaotest@sina.com" andTag:2];
        [self addLabelInFrame:CGRectMake(30, 110, 260, 30) withTitle:@"密码:appfactory" andTag:3];
        
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2-65, 90, 45) withTitle:@"登陆" andTag:4 andAction:@selector(SinaToAccessTokenView:)];
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2+15, 90, 45) withTitle:@"退出" andTag:5 andAction:@selector(SinaLogOut:)];

    }
    return self;
}

#pragma mark 执行登陆判断操作
-(void)SinaToAccessTokenView:(id)sender
{
    //判断令牌是否为空，作为是否登陆的凭证，此凭证在实际应用中建议本地存储，防止每次启动重复登录
    if ([[Utility getInstance]sina_AccessToken]==nil || [[[Utility getInstance] sina_AccessToken] isEqualToString:@""]) 
    {
        SinaLoginViewController* sinaLogincController=[[SinaLoginViewController alloc]init];
        [[self navigationController] pushViewController:sinaLogincController animated:YES];
        [sinaLogincController release];
    }
    else
    {
        SinaMainViewController* sinaMainView=[[SinaMainViewController alloc]init];
        [[self navigationController]pushViewController:sinaMainView animated:YES];
        [sinaMainView release];
    }
}

#pragma mark 退出登录，即清空令牌
- (void)SinaLogOut:(id)sender
{
    if ([[Utility getInstance]sina_AccessToken]!=nil) 
    {
        [[Utility getInstance]setSina_AccessToken:@""];
    }
}

#pragma mark 创建UILabel
- (void)addLabelInFrame:(CGRect)frame withTitle:(NSString*)title andTag:(NSInteger)tag
{
    UILabel* label = [UILabel new];
    [label setFrame:frame];
    [label setText:title];
    [label setTextAlignment:UITextAlignmentCenter];
    [label setTag:tag];
    [label setTextAlignment:UITextAlignmentLeft];
    [self.view addSubview:label];
    MSSafeRelease(label);
}

#pragma mark创建UIButton
- (void)addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
