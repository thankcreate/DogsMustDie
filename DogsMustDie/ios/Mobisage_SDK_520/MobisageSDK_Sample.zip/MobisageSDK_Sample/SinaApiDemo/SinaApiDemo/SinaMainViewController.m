//
//  SinaMainViewController.m
//  SNSDemo
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "SinaMainViewController.h"
#import "SinaLoginViewController.h"
#import "Utility.h"
#import "SinaUpdateStatusViewController.h"
#import "MSSinaFriendshipCreate.h"
#import "MobiSageSDK.h"
#import "JSONKit.h"

@implementation SinaMainViewController

#pragma mark 创建UIButton
-(void) addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

#pragma mark 加关注
-(void)MakeFriends:(id)sender
{
    //根据AppKey和存储的令牌创建对象
    MSSinaFriendshipCreate * createPackage= [[MSSinaFriendshipCreate alloc] initWithAppKey:SinaApp_Key AccessToken:[[Utility getInstance] sina_AccessToken]];
    
    NSLog(@"appkey:%@;sina_token:%@",SinaApp_Key,[[Utility getInstance] sina_AccessToken]);
    //设置参数
    [createPackage addParameter:@"uid" Value:[uidtxt text]];
    [createPackage addParameter:@"screen_name" Value:[nametxt text]];
    //发送
    [[MobiSageManager getInstance] pushMobiSagePackage:createPackage];
    //注册完成后消息
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(onMobiSagePackageFinish:) name:MobiSagePackage_Finish object:createPackage];
    //切记释放
    [createPackage release];
}

#pragma mark 发送完成后的消息
-(void)onMobiSagePackageFinish:(NSNotification*) notify
{
    //线程安全调用方法
    [self performSelectorOnMainThread:@selector(PerformMobiSagePackageFinish:) withObject:notify waitUntilDone:NO];
}

#pragma mark 处理发送完成后的消息
-(void)PerformMobiSagePackageFinish:(NSNotification*) notify
{
    //notify类型是否符合要求
    if ([[notify object] isKindOfClass:[MSSinaFriendshipCreate class]]) {
        //从notify获取对象
        MSSinaFriendshipCreate *package=(MSSinaFriendshipCreate*)[notify object];
        //利用SDK中自带的JSON解析库解析对象
        NSDictionary *resultData=[[[JSONDecoder decoder] objectWithData:package->resultData] retain];
        NSLog(@"result data==============%@",resultData);
        NSLog(@"%@",[resultData objectForKey:@"id"]);
        //判断参数并做相应处理
        if ([resultData objectForKey:@"id"]!=nil) 
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"" message:@"关注成功" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alert show];
            [alert release];
        }
        else if([[resultData objectForKey:@"error"] isEqualToString:@"already followed"])
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"" message:@"已经关注" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alert show];
            [alert release];
            
        }
        else
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"" message:[NSString stringWithFormat:@"错误信息:%@",[resultData objectForKey:@"error"]] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alert show];
            [alert release];
        }
        //切记释放
        [resultData release];
    }
    
}

#pragma mark 进入发送微博界面
-(void)UpdataStatus:(id)sender
{
    SinaUpdateStatusViewController *updateStatusView=[SinaUpdateStatusViewController new];
    [self presentModalViewController:updateStatusView animated:YES];
    [updateStatusView release];
}

#pragma mark 自定义初始化
- (id)init
{
    self = [super init];
    if (self) {
        // Custom initialization
        [[self view] setBackgroundColor:[UIColor whiteColor]];
        
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2-65, 90, 50) withTitle:@"加关注" andTag:1 andAction:@selector(MakeFriends:)];
        
        [self addButtonInFrame:CGRectMake(self.view.bounds.size.width/2-45, self.view.bounds.size.height/2+15, 90, 50) withTitle:@"发微博" andTag:2 andAction:@selector(UpdataStatus:)];
        
        UILabel* uid=[[[UILabel alloc]initWithFrame:CGRectMake(30, 30, 100, 40)]autorelease];
        uidtxt=[[[UITextField alloc]initWithFrame:CGRectMake(110, 30, 200, 40)]autorelease];
        UILabel* name=[[[UILabel alloc]initWithFrame:CGRectMake(30, 90, 100, 40)]autorelease];
        nametxt=[[[UITextField alloc]initWithFrame:CGRectMake(110, 90, 200, 40)]autorelease];
        //只是测试用，您可以输入自己想要测试的关注账号，但是UID只能是数字
        [uid setText:@"UID:"];
        [name setText:@"Name:"];
        [uidtxt setBorderStyle:UITextBorderStyleLine];
        [uidtxt setText:@"1494848464"];
        [uidtxt setTag:3];
        [nametxt setBorderStyle:UITextBorderStyleLine];
        [nametxt setText:@"宁财神"];
        [uidtxt setTag:4];
        
        [self.view addSubview:uid];
        [self.view addSubview:name];
        [self.view addSubview:uidtxt];
        [self.view addSubview:nametxt];
    }
    return self;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isKindOfClass: [UIButton class]] )
    {    
        return NO;
    }
    return YES;
}

-(void)done:(id)sender
{  
    for (UIView *view in self.view.subviews)
    {  
        if ([view isKindOfClass:[UITextField class]]) 
        {  
            [view resignFirstResponder];  
            
        }
    }  
}  

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

-(void)viewDidLoad
{
    [super viewDidLoad];
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(done:)];  
    tapGestureRecognizer.numberOfTapsRequired = 1;  
    tapGestureRecognizer.delegate=self;
    [self.view addGestureRecognizer: tapGestureRecognizer];   //只需要点击非文字输入区域就会响应hideKeyBoard  
    [tapGestureRecognizer release];  
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
//{
//    // Return YES for supported orientations
//    return (interfaceOrientation == UIInterfaceOrientationPortrait);
//}

-(void)dealloc
{
    [super dealloc];
}

@end
