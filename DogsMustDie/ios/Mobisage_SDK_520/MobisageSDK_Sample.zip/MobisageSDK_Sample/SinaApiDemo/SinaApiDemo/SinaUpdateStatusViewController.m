//
//  SinaUpdateStatusViewController.m
//  Main
//
//  Created by zuo shunxing on 12-2-28.
//  Copyright (c) 2012年 mobiSage. All rights reserved.
//

#import "SinaUpdateStatusViewController.h"
#import "Utility.h"
#import "MobiSageSDK.h"
#import "JSONKit.h"
#import "MSSinaStatusUpdate.h"

@implementation SinaUpdateStatusViewController

#pragma mark 创建UIButton
-(void) addButtonInFrame:(CGRect)frame withTitle:(NSString*)buttonTitle andTag:(NSInteger)tag andAction:(SEL)action
{
    UIButton* button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setFrame:frame];
    [button setTitle:buttonTitle forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button setTag:tag];
    [self.view addSubview:button];
}

#pragma mark 发送按钮事件
-(void)PushStatusAction:(id)sender
{
    
    if ([txtView text] !=nil && [txtView text].length !=0)
    {
        NSLog(@"Push Status action using accessToken %@",[[Utility getInstance] sina_AccessToken]);
        //创建MSSinaStatusUpdate对象，同样根据AppKey和Token创建
        MSSinaStatusUpdate *updatePackage=[[MSSinaStatusUpdate alloc]initWithAppKey:SinaApp_Key AccessToken:[[Utility getInstance]sina_AccessToken]];
        //同样的，整一些必要的参数进去
        [updatePackage addParameter:@"status" Value:[txtView text]];
        [updatePackage addParameter:@"lat" Value:@"39.98"];
        [updatePackage addParameter:@"long" Value:@"116.33"];
        [updatePackage addParameter:@"annotations" Value:@"[{\"keywords\":\"老饭\"}]"];
        //注册完成后的消息
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(onMobiSagePackageFinish:) name:MobiSagePackage_Finish object:updatePackage];
        //都弄好了，发送呗
        [[MobiSageManager getInstance] pushMobiSagePackage:updatePackage];
        //切记释放
        [updatePackage release];
    }
    else
    {
        //啥都不写，必须给点提示啊~_~
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:@"消息不能为空！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        [alert release];
    }
}


#pragma mark 不想发了，那就回去吧：取消按钮，返回
-(void)CancelPushStatus:(id)sender
{
    [self dismissModalViewControllerAnimated:YES];
}

#pragma mark 注册的发送完成后消息的方法
-(void)onMobiSagePackageFinish:(NSNotification*) notify
{
    //线程安全的调用方法
    [self performSelectorOnMainThread:@selector(PerformMobiSagePackageFinish:) withObject:notify waitUntilDone:NO];
}

#pragma mark 注册的发送完成后消息的方法：一切的一切都跟加关注是一样一样地
-(void)PerformMobiSagePackageFinish:(NSNotification*) notify
{
    if ([[notify object] isKindOfClass:[MSSinaStatusUpdate class]]) 
    {
        MSSinaStatusUpdate *package=(MSSinaStatusUpdate*)[notify object];
        NSDictionary *resultData=[[[JSONDecoder decoder] objectWithData:package->resultData] retain];
        NSLog(@"%@",resultData);
        NSLog(@"%@",[resultData objectForKey:@"id"]);
        if ([resultData objectForKey:@"id"]!=nil) 
        {
            NSLog(@"Update Success!!!");
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"" message:@"发送成功"delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alert show];
            [alert release];
            [self dismissModalViewControllerAnimated:YES];
        }
        else
        {
            NSLog(@"Update error!!!");
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"" message:[NSString stringWithFormat:@"错误信息:%@",[resultData objectForKey:@"error"]] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alert show];
            [alert release];
            [self dismissModalViewControllerAnimated:YES];
            
        }
        [resultData release];
    }
}

#pragma mark 自定义初始化
- (id)init
{
    self = [super init];
    if (self) {
         [self.view setBackgroundColor:[UIColor grayColor]];
        // Custom initialization
    }
    txtView=[[UITextView alloc]initWithFrame:CGRectMake(30, 30, self.view.bounds.size.width-60, (self.view.bounds.size.height-200)/2)];
    [self addButtonInFrame:CGRectMake(self.view.bounds.size.width-80, self.view.bounds.size.height/2-50, 60, 40) withTitle:@"发送" andTag:1 andAction:@selector(PushStatusAction:)];
    [self addButtonInFrame:CGRectMake(30, self.view.bounds.size.height/2-50, 60, 40) withTitle:@"取消" andTag:2 andAction:@selector(CancelPushStatus:)];
    [self.view addSubview:txtView];
    
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
